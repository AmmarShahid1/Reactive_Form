import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrl: './reactive.component.css'
})
export class ReactiveComponent {
  title = 'Reactive Form';
  
  profileForm = this.formBuilder.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: ['', Validators.required],
    password: ['', Validators.required],
    Cpassword: ['', Validators.required],
    aliases: this.formBuilder.array([this.formBuilder.control('')]),

  });

onSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.profileForm.value);
  }
  updateProfile() {
    this.profileForm.patchValue({
      firstName: 'Ammar',
      lastName: 'Shahid',
      email: 'ammar@gmail.com',
      password: '*****',
      Cpassword: '*****'
    });
  }

  constructor(private formBuilder: FormBuilder) {}
}
